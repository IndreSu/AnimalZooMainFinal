# techin_2023
Egzaminui reikalinga teorija

- TBD...