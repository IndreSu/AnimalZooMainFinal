# RestTemplate
### Is one of techniques to perform API calls

`other technique (non blocking): **WebClient**


### URL's for the task
- https://openweathermap.org/find
- https://openweathermap.org/api
- https://openweathermap.org/price

### Example
`GET http://api.openweathermap.org/data/2.5/weather?id=<CITY ID>&APPID=<REG_ID>&units=metric`