# Object Serialization configuration


### Database migration tool
- JSR 310 (dates)
- Bean configuration
- application (.yaml, .properties) file configuration


### example config: 
- https://www.baeldung.com/spring-boot-customize-jackson-objectmapper
- https://www.baeldung.com/spring-boot-formatting-json-dates