package lt.techin.zoo.api;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RoomControllerTest {

//    @Test
//    void getRooms() {
//    }
//
//    @Test
//    void getRoom() {
//    }
//
//    @Test
//    void deleteRoom() {
//    }
//
//    @Test
//    void createRoom() {
//    }
//
//    @Test
//    void updateRoom() {
//    }
//
//    @Test
//    void executeCustom() {
//    }
//
//    @Test
//    void findLatestByType() {
//    }
}