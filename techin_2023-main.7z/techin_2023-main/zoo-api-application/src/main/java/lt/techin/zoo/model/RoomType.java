package lt.techin.zoo.model;

public enum RoomType {

    LOBBY,
    LOCKED,
    OPEN,
    FORBIDDEN

}
