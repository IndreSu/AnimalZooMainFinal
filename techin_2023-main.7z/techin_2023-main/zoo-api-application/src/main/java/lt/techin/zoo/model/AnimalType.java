package lt.techin.zoo.model;

public enum AnimalType {

    TIGER,
    LION,
    GIRAFFE,
    PARROT,
    RABBIT

}
